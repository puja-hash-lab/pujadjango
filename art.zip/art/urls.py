from django import urls 
from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from django.urls.resolvers import URLPattern
from art import views
from .views import *

urlpatterns =[
path('name',art_image_view, name='Image Upload'),
path('art_image',display_image,name='display_image')
]