from django.db import models

class Art(models.Model):
    name =models.CharField(max_length=50)
    art_image =models.ImageField(upload_to='static/')
    











