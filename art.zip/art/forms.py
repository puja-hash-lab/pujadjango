from django import forms 
from .models import *
# from django.db.models import fields

class ArtForm(forms.ModelForm):
    class Meta:
        model =Art
        fields =['name','art_image']