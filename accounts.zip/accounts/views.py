from django.shortcuts import render
from django.contrib.auth.models import User,auth
from django.contrib import messages
from django.utils.datastructures import MultiValueDictKeyError
from django.shortcuts import redirect

def reg(request):

    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        if password1 == password2:
            if User.objects.filter(email=email).exists():
                messages.info(request,'Email taken')
                return redirect('reg')
            elif User.objects.filter(username=username).exists():
                messages.info(request,'username exists')    
                return redirect('reg')
            else:        
                user = User.objects.create_user(first_name = first_name, last_name = last_name,email = email, username=username, password = password1)
                user.save()
                messages.info(request,'user created')
                return redirect('piclogin')
        else:
            messages.info(request,'password not matching')
            return redirect('reg')
        return redirect('/')
    else:
        return render(request, 'reg.html')

def piclogin(request):
    if request.method == 'POST':
     
        username = request.POST['username']
        password = request.POST['password']
       
        
        user = auth.authenticate(username=username , password = password)
        if user is not None:
            auth.login(request,user)
            request.session['is_logged']= True
            messages.info(request,'You have succesfully logged in')
            return redirect('/')
        else:
            messages.info(request,'invalid credential')
            return redirect('piclogin')
    else:
        return render(request, 'piclogin.html')


def term (request):
        return render(request, 'try.html') 
def forgot (request):
     return render(request, 'forgotpass.html')   
def profile (request):
     return render(request, 'profile.html')   

def logout (request):
    auth.logout(request)
    return redirect('/')




















 








