from django.urls import path

from . import views

urlpatterns = [
    path("reg",views.reg, name="reg"),
    path("piclogin",views.piclogin,name="piclogin"),
    path('try',views.term,name='term'),
    path('forgotpass',views.forgot,name='forgotpass'),
    path('logout',views.logout,name='logout'),
    path('profile',views.profile,name='profile')
]
    #path('about',views.about,name='about_us'),
    #path('contactus',views.contact,name='contactus'),
   # path('try',views.term,name='term')
    #path('forgotpass',views.forgot,name='forgotpass')

