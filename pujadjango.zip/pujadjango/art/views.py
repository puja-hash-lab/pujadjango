from django.shortcuts import render ,redirect
from django.http import HttpResponse
from .forms import *

# Create your views here.

def art_image_view(request): 
    if request.method=='POST':
        image=Art()
        form = ArtForm(request.POST, request.FILES,instance=image)

        if form.is_valid():
            form.save()
            return redirect('/')
    else:
        form=ArtForm()   
        return render(request,'art.html',{'Artform':form})  

def display_image(request) :
    if request.method=='GET':
        Arts =Art.objects.all()
        return render(request,'learn.html',{'art_images':Arts})       
