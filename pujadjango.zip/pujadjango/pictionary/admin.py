from django.contrib import admin
from .models import Picture
# Register your models here.

admin.site.register(Picture)
