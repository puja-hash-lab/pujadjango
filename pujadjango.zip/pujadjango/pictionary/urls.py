from django.urls import path
from . import views

urlpatterns = [
    path('',views.nav,name='nav'),
    path('picsignup',views.picsignup,name='picsignup'),
    path('piclogin',views.piclogin,name='piclogin'),
    path("about",views.about,name="about"),
    path('contactus',views.contact,name='contactus'),
    path('try',views.term,name='term'),
    path('forgotpass',views.forgot,name='forgotpass'),
    path('learn',views.learn,name='learn'),
    path('art',views.art,name='art')
]