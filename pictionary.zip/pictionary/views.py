from django.shortcuts import render
from django.http import HttpResponse
from .models import Picture


def nav (request):
    return render(request, "nav.html")

def piclogin(request):
    return render (request,'piclogin.html')    

def picsignup(request):
    return render (request,'picsignup.html') 
 
def about(request):
     return render(request, 'about.html')

def contact(request):
     return render(request, 'contactus.html')

def term (request):
     return render(request, 'try.html')

def forgot (request):
     return render(request, 'forgotpass.html')

def learn (request):
     return render(request, 'learn.html') 

def profile (request):
     return render(request, 'profile.html')  
    
def reg (request):
     return render(request, 'reg.html')   

def art (request):
     return render(request, 'art.html')  

def pro (request):
     return render(request, 'pro.html')      

def privacy (request):
     return render(request, 'privacy.html')     
     

def notification (request):
     return render(request, 'notification.html')  
def help (request):
     return render(request, 'help.html')  
def policy (request):
     return render(request, 'policy.html')                


